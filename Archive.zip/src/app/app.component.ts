import { Component, ElementRef, ViewChild } from '@angular/core';
import { SvgService } from './services/svg.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'bounding';

  selected1: boolean = false;
  selected2: boolean = false;

  @ViewChild('wrapper') svgWrapper?: ElementRef<HTMLDivElement>;
  @ViewChild('svg') svg?: ElementRef<HTMLElement>;
  svgLine?: SVGLineElement = undefined;

  constructor(svgService: SvgService) {
    svgService.lineStarted.subscribe((data) => {
      if (!data.valid) return;

      this.svgLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      this.svgLine.setAttribute('x1', (data.current.x - this.svgWrapper!.nativeElement.offsetLeft).toString());
      this.svgLine.setAttribute('y1', (data.current.y - this.svgWrapper!.nativeElement.offsetTop).toString());
      this.svgLine.setAttribute('x2', (data.current.x - this.svgWrapper!.nativeElement.offsetLeft).toString());
      this.svgLine.setAttribute('y2', (data.current.y - this.svgWrapper!.nativeElement.offsetTop).toString());
      this.svgLine.setAttribute("stroke", "black")
      this.svg!.nativeElement.append(this.svgLine);
    });

    svgService.lineDrawing.subscribe((data) => {
      if (!data.valid || !this.svgLine) return;

      this.svgLine.setAttribute('x2', (data.current.x - this.svgWrapper!.nativeElement.offsetLeft).toString());
      this.svgLine.setAttribute('y2', (data.current.y - this.svgWrapper!.nativeElement.offsetTop).toString());
    });


    svgService.lineEnded.subscribe(() => {
      if (this.svgLine) {
        
        this.svg!.nativeElement.removeChild(this.svgLine);
        delete this.svgLine;

      }
    })

    svgService.dropped.subscribe((data) => {
      if (!data.valid || !data.accepted || this.svgLine === undefined) return;
      
      this.svgLine.setAttribute('x2', (data.current.x - this.svgWrapper!.nativeElement.offsetLeft).toString());
      this.svgLine.setAttribute('y2', (data.current.y - this.svgWrapper!.nativeElement.offsetTop).toString());

      this.svgLine = undefined;

      console.log('deleted')
    })
  }

  select(num: number) {
    if(num === 1) this.selected1 = !this.selected1;
    else this.selected2 = !this.selected2;
  }
}
