import { Component, ElementRef, HostBinding, Input } from '@angular/core';
import { BoxItem, DragDetails, typesList } from './bounding-box.interfaces';
import { SvgService } from 'src/app/services/svg.service';
import { generateRandomId } from 'src/app/miscellaneous/helpers';

@Component({
  selector: 'bounding-box',
  templateUrl: './bounding-box.component.html',
  styleUrls: ['./bounding-box.component.scss'],
})
export class BoundingBoxComponent {
  // #region Constants
  readonly fallback: BoxItem = {
    id: '',
    path: '../../../assets/close.svg',
    alt: 'Not found',
  };
  // #endregion

  // #region Variables
  private types = new Map<string, BoxItem>(typesList.map((e) => [e.id, e]));
  private dragId: number = NaN;
  protected _type: BoxItem = this.fallback;
  // #endregion

  // #region Properties
  get type(): string {
    return this._type.id;
  }

  @Input() set type(value: string) {
    this._type = this.types.get(value) || this.fallback;
  }

  @HostBinding('class.selected') @Input() selected: boolean = false;
  @HostBinding('class.hide-border') @Input() hideBorder: boolean = false;
  @Input() hideHandles: boolean = false;
  // #endregion

  // #region Constructor
  constructor(private host: ElementRef, private svgService: SvgService) {}
  // #endregion

  // #region Events
  onHandleDragStart(event: DragEvent) {
    this.dragId = generateRandomId();

    const data: DragDetails = {
      senderId: this.host.nativeElement.id,
      dragId: this.dragId,
    };

    event.dataTransfer!.effectAllowed = 'copy';
    event.dataTransfer!.dropEffect = 'copy';
    event.dataTransfer?.setData('text', JSON.stringify(data));

    const handle = event.target as HTMLDivElement;
    const { x, y } = handle.getBoundingClientRect();
    this.svgService.startLine(this.dragId, {
      x: x + handle.offsetWidth / 2,
      y: y + handle.offsetHeight / 2,
    });
  }

  onHandleDragging(event: DragEvent) {
    this.svgService.drawLine(this.dragId, {
      x: event.clientX,
      y: event.clientY,
    });
  }

  onHandleDragEnd() {
    this.svgService.endLine(this.dragId);
  }

  onHandleDragOver(event: DragEvent) {
    event.preventDefault();
  }

  onHandleDrop(event: DragEvent) {
    event.preventDefault();

    const data: DragDetails = JSON.parse(event.dataTransfer!.getData('text'));
    if (
      !this.svgService.valid(data.dragId) ||
      this.host.nativeElement.id === data.senderId
    )
      return;

    const handle = event.target as HTMLDivElement;
    const { x, y } = handle.getBoundingClientRect();
    this.svgService.dropRecieved(data.dragId, {
      x: x + handle.offsetWidth / 2,
      y: y + handle.offsetHeight / 2,
    });
  }
  // #endregion
}
