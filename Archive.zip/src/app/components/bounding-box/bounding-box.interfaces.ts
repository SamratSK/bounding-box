export interface BoxItem {
  id: string;
  path: string;
  alt: string;
}

export interface DragDetails {
  senderId: string;
  dragId: number;
}

export const typesList: BoxItem[] = [
  {id: 'ai', path: '../../../assets/illustrator.svg', alt: 'Illustrator'},
  {id: 'ps', path: '../../../assets/photoshop.svg', alt: 'Photoshop'},
];