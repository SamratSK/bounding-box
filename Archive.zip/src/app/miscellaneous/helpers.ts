export const generateRandomId = (): number => {
  const now = new Date();
  return (
    (now.getMinutes() * 100 + now.getSeconds()) * 100 +
    Math.floor(Math.random() * 100 + 1)
  );
}