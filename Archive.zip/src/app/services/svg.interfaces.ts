export interface Point {
  x: number;
  y: number;
}

export interface LineData {
  current: Point;
  valid: boolean;
}

export interface LineResult {
  current: Point;
  valid: boolean;
  accepted: boolean;
}