import { Injectable } from '@angular/core';
import { LineData, LineResult, Point } from './svg.interfaces';
import { BehaviorSubject, Observable, ReplaySubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SvgService {
  // #region  Constants
  readonly fallbackLineData: LineData = {
    current: { x: 0, y: 0 },
    valid: false,
  };
  
  readonly fallbackLineResult: LineResult = {
    current: { x: 0, y: 0 },
    valid: false,
    accepted: false,
  }
  // #endregion

  // #region Variables
  private currentlyDragged: number[] = [];
  // #endregion

  // #region Subjects
  lineStarted: BehaviorSubject<LineData> = new BehaviorSubject(this.fallbackLineData);
  lineDrawing: BehaviorSubject<LineData> = new BehaviorSubject(this.fallbackLineData);
  dropped: BehaviorSubject<LineResult> = new BehaviorSubject(this.fallbackLineResult);
  lineEnded: BehaviorSubject<null> = new BehaviorSubject(null);
  // #endregion

  startLine(id: number, point: Point) {
    this.currentlyDragged.push(id);
    this.lineStarted.next({current: point, valid: true});
  }

  drawLine(id: number, point: Point) {
    if(!this.currentlyDragged.includes(id)) return;
    this.lineDrawing.next({current: point, valid: true});
  }

  endLine(id: number) {
    if(!this.currentlyDragged.includes(id)) return;
    this.lineEnded.next(null);
  }

  dropRecieved(id: number, point: Point) {
    if(!this.currentlyDragged.includes(id)) return;

    this.dropped.next({current: point, accepted: true, valid: true});
    this.currentlyDragged.splice(this.currentlyDragged.indexOf(id));
  }

  valid(id: number) {
    return this.currentlyDragged.includes(id);
  }
}
